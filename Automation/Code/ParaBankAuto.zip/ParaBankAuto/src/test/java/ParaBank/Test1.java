package ParaBank;


import Setup.Account;
import Setup.Base_page_Close;
import Setup.Bill_Pay;
import Setup.Login_Page;
import org.testng.annotations.Test;

public class Test1 extends Base_page_Close {
    Login_Page log = new Login_Page();
    Account acc = new Account();
    Bill_Pay bill = new Bill_Pay();

    @Test
    public void verifyInvalidLoginShowsError() {
        log.login("SASA", "DASD");
        acc.verifyerror();
    }

    @Test
    public void virfyopennewacc() {
        log.login("sasa", "sasasa");
        acc.accounttype();
        acc.accountnumber();
        acc.assertnewacc();
    }

    @Test
    public void rejectSpecialCharacterPayee() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.enterPayeeName("John@Doe!");
        bill.fillValidData();
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void acceptValidPayee() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterPayeeName("Ahmed Ali");
        bill.clickSendPayment();
        bill.assertSuccess();
    }

    @Test
    public void TC_050_rejectBlankPayee() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.enterPayeeName("");
        bill.fillValidData();
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void TC_051_rejectLeadingSpacePayee() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.enterPayeeName(" Ahmed");
        bill.fillValidData();
        bill.clickSendPayment();
        bill.assertError();
    }
    @Test
    public void TC_052_validAccountMatch() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAccountNumbers("12345", "12345");
        bill.clickSendPayment();
        bill.assertSuccess();
    }

    @Test
    public void TC_053_invalidAccountMismatch() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAccountNumbers("12345", "54321");
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void TC_054_blankAmount() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAmount("");
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void TC_055_nonNumericAmount() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAmount("100a");
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void TC_056_zeroAmount() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAmount("0");
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void TC_057_amountMoreThanBalance() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAmount("6000");
        bill.clickSendPayment();
        bill.assertError();
    }

    @Test
    public void TC_058_validAmountInRange() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAmount("100");
        bill.clickSendPayment();
        bill.assertSuccess();
    }

    @Test
    public void TC_059_invalidSourceAccount() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.enterAccountNumbers("999", "999");
        bill.fillValidData();
        bill.clickSendPayment();
        bill.assertError();
    }


    @Test
    public void TC_060_debitSourceAccountAfterPayment() {
        log.login("sasa", "sasasa");
        bill.openBillPay();
        bill.fillValidData();
        bill.enterAmount("100");
        bill.clickSendPayment();
        bill.assertSuccess();
    }

}
