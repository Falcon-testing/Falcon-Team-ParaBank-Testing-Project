package ParaBank;
import Setup.Account;
import Setup.Base_Page_OPEN;
import Setup.Login_Page;
import org.testng.annotations.Test;

public  class Auto extends Base_Page_OPEN {
    Login_Page log = new Login_Page();
    Account acc = new Account();

    //sabonaaaaaaa
    @Test(priority = 1)
    public void testLoginAndOverview() {
        log.login("sasa", "sasasa");
        acc.verifyHeader();

    }
    @Test(priority = 2 ,dependsOnMethods = "testLoginAndOverview")
    public void verifyAccountFieldDisplayedTest () {
        acc.verifyAccountFieldDisplayed();
    }



































}

























