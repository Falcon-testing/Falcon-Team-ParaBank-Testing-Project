package Setup;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class Bill_Pay extends Base_page_Close{
    By billPayLink = By.linkText("Bill Pay");

    By payeeName = By.name("payee.name");
    By payeeAddress = By.name("payee.address.street");
    By payeeCity = By.name("payee.address.city");
    By payeeState = By.name("payee.address.state");
    By payeeZip = By.name("payee.address.zipCode");
    By payeePhone = By.name("payee.phoneNumber");
    By payeeAccount = By.name("payee.accountNumber");
    By verifyAccount = By.name("verifyAccount");
    By amount = By.name("amount");
    By sendPaymentBtn = By.xpath("//input[@value='Send Payment']");

    By successMsg = By.xpath("//h1[contains(text(),'Bill Payment Complete')]");
    By errorMsg = By.xpath("//span[@class='error']");

    public void clickSendPayment() {
        driver.findElement(sendPaymentBtn).click();
    }
    public void openBillPay() {
        driver.findElement(billPayLink).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(payeeName));
    }

    public void fillValidData() {
        driver.findElement(payeeName).sendKeys("sabo sabona");
        driver.findElement(payeeAddress).sendKeys("Street 22");
        driver.findElement(payeeCity).sendKeys("Cairo");
        driver.findElement(payeeState).sendKeys("CA");
        driver.findElement(payeeZip).sendKeys("12345");
        driver.findElement(payeePhone).sendKeys("01000000000");
        driver.findElement(payeeAccount).sendKeys("12345");
        driver.findElement(verifyAccount).sendKeys("12345");
        driver.findElement(amount).sendKeys("100");
    }


    public void assertSuccess() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(successMsg));
        Assert.assertTrue(driver.findElement(successMsg).isDisplayed());
    }

    public void assertError() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsg));
        Assert.assertTrue(driver.findElement(errorMsg).isDisplayed());
    }

    public void enterPayeeName(String value) {
        driver.findElement(payeeName).clear();
        driver.findElement(payeeName).sendKeys(value);
    }

    public void enterAccountNumbers(String acc, String verify) {
        driver.findElement(payeeAccount).clear();
        driver.findElement(payeeAccount).sendKeys(acc);
        driver.findElement(verifyAccount).clear();
        driver.findElement(verifyAccount).sendKeys(verify);
    }

    public void enterAmount(String value) {
        driver.findElement(amount).clear();
        driver.findElement(amount).sendKeys(value);
    }
}