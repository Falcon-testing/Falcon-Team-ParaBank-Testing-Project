package Setup;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Login_Page extends Base_Page_OPEN {
    By username_loc_path = By.xpath("//input[@name='username']");
    By password_loc_path = By.xpath("//input[@name='password']");
    By login_btn_locc = By.xpath("//input[@type='submit']");

/*
    public void Username() {
        driver.findElement(username_loc_path).click();
    }
 */
    public void enterUsername(String username) {
       driver.findElement(username_loc_path).sendKeys(username);
    }
    public void enterPassword(String password) {
        driver.findElement(password_loc_path).sendKeys(password);
    }
    public void clickLogin() {
        driver.findElement(login_btn_locc).click();
    }
    public void login (String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLogin();



    }

}
