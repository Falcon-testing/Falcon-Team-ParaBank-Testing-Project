package Setup;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

public class Base_Page_OPEN extends Hock {


    @BeforeClass(alwaysRun = true)
    public void set_up(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\puzzle pc\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        Hock.driver = new ChromeDriver();
        Hock.driver.manage().window().maximize();
        Hock.wait = new WebDriverWait(Hock.driver, Duration.ofSeconds(5));
        Hock.driver.get("http://localhost:8080/parabank-5.0.0-SNAPSHOT/index.htm");
    }


  /*  @AfterClass(alwaysRun = true)
    public void finish(){
        Hock.driver.quit();

    }

   */
}

