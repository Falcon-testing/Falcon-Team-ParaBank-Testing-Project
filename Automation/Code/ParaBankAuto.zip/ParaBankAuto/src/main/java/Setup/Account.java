package Setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Account extends Base_Page_OPEN {
    By Accountover_path = By.xpath("//h1[contains(text(), 'Accounts Overview')]");
    By Error_loc_path = By.xpath("//h1[@class='title']");
    By account_table = By.xpath("//table[@id='accountTable']");
    By opennewacc = By.linkText("Open New Account");
    By opennewacctype = By.xpath("//select[@id='type']");
    By accountidnewacc = By.xpath("//select[@id='fromAccountId']");
    By openacc_btn_loc = By.xpath("//input[@class='button']");
    By account_open = By.xpath("//h1[contains(text(),'Account Opened!')]");

    public void verifyHeader() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(Accountover_path));
        WebElement welcome = driver.findElement(Accountover_path);
        Assert.assertEquals(welcome.getText(), "Accounts Overview");
    }
    public void verifyerror() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(Error_loc_path));
        WebElement error = driver.findElement(Error_loc_path);
        Assert.assertEquals(error.getText(), "Error!");
    }

    public void verifyAccountFieldDisplayed() {
        WebElement accounts  = driver.findElement(account_table);
        Assert.assertTrue(accounts.isDisplayed());
    }

    public void accounttype(){
        driver.findElement(opennewacc).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(opennewacctype));
        Select select = new Select(driver.findElement(opennewacctype));
        select.selectByIndex(0);
        Assert.assertEquals(select.getFirstSelectedOption().getText(), "CHECKING");

    }

    public void accountnumber(){
        Select select = new Select(driver.findElement(accountidnewacc));
        select.selectByIndex(0);
        driver.findElement(openacc_btn_loc).click();
    }

    public void assertnewacc(){
        WebElement opacc = driver.findElement(account_open);
        Assert.assertEquals(opacc.getText(), "Account Opened!");

    }

}
