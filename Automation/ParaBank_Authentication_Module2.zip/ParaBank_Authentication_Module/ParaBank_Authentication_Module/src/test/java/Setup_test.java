import Hook.hook;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;


public class Setup_test extends Setup_page  {





    Login_Page log =new Login_Page(driver);

  system system=new system(driver);



}
